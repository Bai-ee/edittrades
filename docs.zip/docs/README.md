# Documentation Index

Complete documentation for the trading system, including strategies, indicators, and best practices.

---

## Strategy Documentation

### Core Strategy Guides

- **`STRATEGY_IMPLEMENTATION_GUIDE.md`** - Complete reference for all 4 strategies (SWING, TREND_4H, SCALP_1H, MICRO_SCALP)
  - Gatekeepers, entry logic, SL/TP calculations
  - Confidence scoring
  - Data structure reference

- **`STRATEGY_MODES.md`** - STANDARD vs AGGRESSIVE mode differences
  - Thresholds and configuration
  - Position sizing
  - When to use each mode

- **`ADDING_STRATEGIES.md`** - Best practices for adding new strategies
  - Step-by-step integration guide
  - Code templates
  - Testing checklist

- **`STRATEGY_SYSTEM_AUDIT.md`** - System architecture and comprehensive audit
  - Data flow diagrams
  - API endpoints
  - Identified inconsistencies

### Strategy Documentation Review

- **`STRATEGY_DOCUMENTATION_REVIEW.md`** - Review of all strategy docs
- **`STRATEGY_DOCS_RECOMMENDATIONS.md`** - Recommendations and action plan

---

## Indicator Documentation

### Core Indicator Guides

- **`INDICATOR_ARCHITECTURE.md`** - System overview and data flow
  - How indicators propagate through the system
  - Integration points
  - Indicator object structure

- **`ADDING_INDICATORS.md`** - Step-by-step guide for adding indicators
  - Complete 50 EMA example
  - Common patterns
  - Troubleshooting

- **`INDICATOR_REFERENCE.md`** - Current indicators catalog
  - EMA21, EMA200, Stochastic RSI
  - Trend, Pullback State, Swing Points
  - Specifications and usage

- **`INDICATOR_INTEGRATION_CHECKLIST.md`** - Quick reference checklist

- **`INDICATOR_DOCUMENTATION_INDEX.md`** - Documentation index and quick start

### Indicator Templates

Located in `docs/templates/`:

- **`indicator-calculation-template.js`** - Calculation layer template
- **`indicator-strategy-template.js`** - Strategy usage template
- **`indicator-frontend-template.html`** - Frontend display template
- **`indicator-json-template.js`** - JSON export template

---

## Other Documentation

- **`BACKTEST_GUIDE.md`** - Backtest system documentation
- **`MARKETDATA_MODULE.md`** - Market data module reference
- **`technical-data-requirements.md`** - Technical data requirements

---

## Archived Documentation

Historical strategy documentation has been moved to `docs/archive/`:

- `SWING_STRATEGY_IMPLEMENTATION.md` (consolidated into STRATEGY_IMPLEMENTATION_GUIDE.md)
- `MICRO_SCALP_IMPLEMENTATION.md` (consolidated into STRATEGY_IMPLEMENTATION_GUIDE.md)
- `AGGRESSIVE_MODE_IMPLEMENTATION.md` (replaced by STRATEGY_MODES.md)
- `FLEXIBLE_STRATEGY_COMPLETE.md` (consolidated)
- `FLEXIBLE_STRATEGY_UPDATE.md` (historical)
- `MICRO_SCALP_EXAMPLES.md` (may be outdated)

See `docs/archive/README.md` for details.

---

## Quick Start

### Adding a New Indicator

1. Read `INDICATOR_ARCHITECTURE.md` - Understand the system
2. Follow `ADDING_INDICATORS.md` - Step-by-step guide
3. Use templates in `docs/templates/` - Code patterns
4. Reference `INDICATOR_REFERENCE.md` - Current indicators

### Adding a New Strategy

1. Read `STRATEGY_IMPLEMENTATION_GUIDE.md` - Current strategies
2. Follow `ADDING_STRATEGIES.md` - Integration guide
3. Review `STRATEGY_MODES.md` - Mode differences
4. Test thoroughly using checklist

### Understanding the System

1. Start with `STRATEGY_ARCHITECTURE.md` (or `STRATEGY_SYSTEM_AUDIT.md`)
2. Review `STRATEGY_IMPLEMENTATION_GUIDE.md` for strategy details
3. Check `INDICATOR_ARCHITECTURE.md` for indicator system
4. Reference specific guides as needed

---

## Documentation Structure

```
docs/
├── README.md (this file)
├── Strategy Documentation
│   ├── STRATEGY_IMPLEMENTATION_GUIDE.md
│   ├── STRATEGY_MODES.md
│   ├── ADDING_STRATEGIES.md
│   ├── STRATEGY_SYSTEM_AUDIT.md
│   ├── STRATEGY_DOCUMENTATION_REVIEW.md
│   └── STRATEGY_DOCS_RECOMMENDATIONS.md
├── Indicator Documentation
│   ├── INDICATOR_ARCHITECTURE.md
│   ├── ADDING_INDICATORS.md
│   ├── INDICATOR_REFERENCE.md
│   ├── INDICATOR_INTEGRATION_CHECKLIST.md
│   └── INDICATOR_DOCUMENTATION_INDEX.md
├── Templates
│   ├── indicator-calculation-template.js
│   ├── indicator-strategy-template.js
│   ├── indicator-frontend-template.html
│   └── indicator-json-template.js
├── Archive
│   ├── README.md
│   └── [archived files]
└── Other
    ├── BACKTEST_GUIDE.md
    ├── MARKETDATA_MODULE.md
    └── technical-data-requirements.md
```

---

## Maintenance

When updating documentation:

1. **Keep it current** - Update docs when code changes
2. **Verify accuracy** - Check data paths and logic match code
3. **Test examples** - Ensure code examples work
4. **Cross-reference** - Link related documents
5. **Archive old versions** - Move outdated docs to archive

---

**Last Updated:** 2025-01-XX  
**Version:** 1.0.0

